const help = (prefix) => {
	return `𝗗𝗜𝗟𝗕𝗢𝗧
	
	                
┏━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━┓
┃
┏❉ *${prefix}owner*
┣❉ *${prefix}donasi*
┗❉ *${prefix}creator*
┃
┣━━━°❀ ❬ 𝗠𝗔𝗞𝗘𝗥 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}sticker* [foto]
┣➥ *${prefix}stickergif* [foto]
┣➥ *${prefix}sticker nobg 
┣➥ *${prefix}thunder* [teks]
┣➥ *${prefix}tsticker* [teks/url]
┃
┣━━━━°❀ ❬ 𝙈𝙀𝘿𝙄𝘼 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}tts* [teks]
┣➥ *${prefix}ocr*
┣➥ *${prefix}loli*
┣➥ *${prefix}toimg*
┣➥ *${prefix}meme*
┣➥ *${prefix}memeindo*
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}wait* [foto]
┣➥ *${prefix}simi
┣➥ *${prefix}simih*
┣➥ *${prefix}wait*
┃
┣━━━━°❀ ❬ 𝙂𝙍𝙊𝙐𝙋 ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}setname*
┣➥ *${prefix}setdesc*
┣➥ *${prefix}getpp*
┣➥ *${prefix}tagall*
┣➥ *${prefix}linkgroup
┣➥ *${prefix}gprofile*
┣➥ *${prefix}setprefix
┣➥ *${prefix}welcome*
┣➥ *${prefix}left*
┃
┣━━━━°❀ ❬ 𝙎𝙊𝙐𝙉𝘿 ❭ ❀°━━━━━⊱
┃
┣➥ *salam*
┣➥ *tariksis*
┣➥ *baka*
┣➥ *desah*
┣➥ *goblok*
┣➥ *roti*
┣➥ *welot*
┣➥ *abangjago*
┣━━━━━━━━━━━━━━━━━━━━
┃      𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬 𝗙𝗔𝗗𝗜𝗟
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.help = help

